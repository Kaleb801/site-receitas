
    var familiaimg0=["","images/image6.jpg","images/image7.jpg","images/image8.jpg","images/image9.jpg"];
    var familiafig0=["","Salcicha empanada","Arroz branco","Caldo de mandioca","Sopa de legumes"];
    var familialin0=["","salcichaempanada","arrozbranco","caldodemandioca","sopadelegumes"];

    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const receita = urlParams.get('receita')
    var fields = receita.split('_')
    document.getElementById("titulo").textContent=fields[0]
    
    switch (receita){  
        case "familia_0": document.getElementById("bnt1").onclick = function() {
            location.href='recipes.html?receita=familia_'+(parseInt(fields[1])+1).toString();
        }
        fill(familiaimg0,familiafig0,familialin0)
    }

    function fill(array1,array2,array3){
        document.getElementById("figcap1").onclick = function() {
        location.href='recipe.html?receita='+array3[1];
        }
        document.getElementById("figcap2").onclick = function() {
        location.href='recipe.html?receita='+array3[2];
        }
        document.getElementById("figcap3").onclick = function() {
        location.href='recipe.html?receita='+array3[3];
        }
        document.getElementById("figcap4").onclick = function() {
        location.href='recipe.html?receita='+array3[4];
        }
        for (var i = 1; i < 5; i++) {
            document.getElementById("image"+i.toString()).src=array1[i]
            document.getElementById("figcap"+i.toString()).textContent=array2[i]
        }
     }