
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const receita = urlParams.get('receita')

    switch (receita){  
        case "salcichaempanada": document.getElementById("image1").src="images/image6.jpg"
        document.getElementById("mdpi").textContent=
        "1 copo de leite, 1 colher de sopa de manteiga ou margarina, 1 pitada de sal, 1 pitada de arisco, 1 1/2 xícaras de farinha de trigo, 10 salsichas de hot dog, 1 ovo Farinha de rosca para polvilhar, Óleo para fritar"
        document.getElementById("mdpm").textContent="Leve o leite ao fogo junto com a manteiga, arisco e o sal. Quando estiver quase fervendo coloque a farinha de trigo, mexendo bem. Apague o fogo e deixe a massa esfriar um pouco. Corte as salsichas no meio e escalde. Depois que a massa esfriar mexa como uma massinha de modelar para pegar o ponto.Envolva a massa nas salsichas, passe no ovo e na farinha de rosca. Frite até ficar dourado e deixe no papel toalha para retirar o excesso de gordura."
        document.getElementById("figcap1").textContent="Salcicha empanada";
        break;
        case "arrozbranco":document.getElementById("image1").src="images/image7.jpg"
        document.getElementById("mdpi").textContent="2 dentes de alho picados, 1 fio de sopa de óleo, 1 colher de chá de sal, 2 xícaras de arroz, 3 xícaras de água quente"
        document.getElementById("mdpm").textContent="Lave bem o arroz. Coloque a água para ferver. Soque o alho picado. Em seguida, numa panela, coloque o alho picado e socado, espere.Acrescente então o óleo e deixe dourar. Quando o alho começar a suar, adicione o arroz. Refogue o arroz, e em seguida, coloque a água quente e o sal. Baixe o fogo, deixe a panela semi-tampada e deixe cozinhar até a água secar. Pronto."
        document.getElementById("figcap1").textContent="Arroz branco";
        break;
        case "caldodemandioca":document.getElementById("image1").src="images/image8.jpg"
        document.getElementById("mdpi").textContent="1 kg de carne cozida desfiada, 3 lingüiças calabresa, 200g de bacon, 1 kg de mandioca (ou aipim, ou macaxeira), 2 cebolas grandes, 10 dentes de alho, cebolinha, salsinha, 500 g de torresmo"
        document.getElementById("mdpm").textContent="Cozinhe a mandioca em água e sal, Quando estiver bem molinhha, bata no liquidificador com água, ou com o caldo da carne cozida. Numa panela, frite a lingüiça e o bacon. Com uma escumadeira, retire e coloque em papel toalha, para absorver a gordura. Depois, refogue a cebola e o alho. Acresecente a carne cozida desfiada, a lingüiça, e o bacon. Depois junte a mandioca batida.  Acrescente um pouco de água para ferver, e formar um caldo, como se fosse uma sopa. Sirva em pratos e coloque por cima a cebolinha e a salsinha, e os torresmos. " 
        document.getElementById("figcap1").textContent="Caldo de mandioca";
        case "sopadelegumes":document.getElementById("image1").src="images/image9.jpg"
        document.getElementById("mdpi").textContent="1 colher (sopa) de óleo, 1 cebola pequena picada, 1 cenoura média cortada em cubos pequenos, 1 batata média cortada em cubos pequenos, 1500 mililitros de água, 2 Cubos de Caldo Knorr Legumesknorr Logo, 1/2 xícara de chá de abóbora pescoço cortada em cubos pequenos, 1/2 xícara de chá de vagem picada, 70 gramas de macarrão Knorr Padre Nossoknorr Logo"
        document.getElementById("mdpm").textContent="Aqueça o óleo em uma panela e refogue a cebola. Adicione a cenoura e a batata, refogando rapidamente. Junte a água e o Caldo Knorr Legumes. Quando levantar fervura, acrescente a abóbora e a vagem. Cozinhe, em fogo médio, por mais 10 minutos e junte o macarrão Knorr. Cozinhe em fogo médio até o macarrão estar al dente (aproximadamente 12 minutos). Salpique a salsinha picada. Sirva em seguida." 
        document.getElementById("figcap1").textContent="Sopa de legumes";
    }